﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
public class Water : Task
{
    //private SpriteRenderer childWaterRenderer;
    // Start is called before the first frame update
    void Start()
    {
        if (type == TaskType.Sweep)
        {
            SpriteRenderer[] renderers = GetComponentsInChildren<SpriteRenderer>();
            childWaterRenderer = renderers[renderers.Length - 1];
        }
    }

    private void Update()
    {
        childWaterRenderer.transform.localScale += Time.deltaTime * 0.1f * (Vector3)Vector2.one;
        duration += Time.deltaTime * 0.1f;
    }
}
*/
